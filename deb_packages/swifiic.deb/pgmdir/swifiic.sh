#!/bin/bash
apt-get update  # To get the latest package lists
sudo apt-get install tomcat8-user tomcat8-common mysql-server openjdk-8-jdk default-jre -y

#etc


 
