
	proj="msngr/msngr-hub.jar"
        classToRun="in.swifiic.app.msngr.hub.Messenger"
    