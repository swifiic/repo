
        proj="suta/suta-hub.jar"
        classToRun="in.swifiic.plat.app.suta.hub.Suta"
    