#!/bin/bash
echo "Checking Whether Setup is proper"

echo " implementation pending"

read -p "Enter the base directory for SWIFiIC Installation Eg. /opt/swifiic" base_directory


source ${base_directory}/properties/setEnv.sh

# to do - try to run java code to check SQL schema access


# to do - try to check IBR-DTN service by ping or similar small app


# to do - try to check SOA access using local HTTP queries


